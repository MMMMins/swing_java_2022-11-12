/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QnA;

/**
 *
 * @author min_
 */
public class AnswerVO {
    private String memCode;
    private String q_index;
    private String a_index;
    private String answerText;
    private String answerDate;

    public String getMemCode() {
        return memCode;
    }

    public void setMemCode(String memCode) {
        this.memCode = memCode;
    }

    public String getQ_index() {
        return q_index;
    }

    public void setQ_index(String q_index) {
        this.q_index = q_index;
    }

    public String getA_index() {
        return a_index;
    }

    public void setA_index(String a_index) {
        this.a_index = a_index;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public String getAnswerDate() {
        return answerDate;
    }

    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }
    
    
}
